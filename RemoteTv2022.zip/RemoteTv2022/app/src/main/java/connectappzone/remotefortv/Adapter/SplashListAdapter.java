package connectappzone.remotefortv.Adapter;

import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import connectappzone.remotefortv.Model.SplashModel;
import connectappzone.remotefortv.R;
import java.util.ArrayList;

public class SplashListAdapter extends RecyclerView.Adapter<SplashListAdapter.ViewHolder> {
    /* access modifiers changed from: private */
    public Context mContext;
    /* access modifiers changed from: private */
    public ArrayList<SplashModel> splashAppList;

    public SplashListAdapter(Context context, ArrayList<SplashModel> arrayList) {
        this.mContext = context;
        this.splashAppList = arrayList;
    }

    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        return new ViewHolder(LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.splash_list_item, viewGroup, false));
    }

    public void onBindViewHolder(ViewHolder viewHolder, @SuppressLint("RecyclerView") final int i) {
        SplashModel splashModel = this.splashAppList.get(i);
        ((RequestBuilder) Glide.with(this.mContext).load(splashModel.getAppUrl()).placeholder((int) R.mipmap.ic_launcher)).into(viewHolder.iv_splash_item);
        viewHolder.tv_splash_item.setText(splashModel.getAppName());
        viewHolder.tv_install.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    SplashListAdapter.this.mContext.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(((SplashModel) SplashListAdapter.this.splashAppList.get(i)).getAppLink())));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(SplashListAdapter.this.mContext, "You don't have Google Play installed", 1).show();
                }
            }
        });
    }

    public int getItemCount() {
        return this.splashAppList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        /* access modifiers changed from: private */
        public ImageView iv_splash_item;
        /* access modifiers changed from: private */
        public TextView tv_install;
        /* access modifiers changed from: private */
        public TextView tv_splash_item;

        public ViewHolder(View view) {
            super(view);
            this.tv_install = (TextView) view.findViewById(R.id.tv_install);
            this.iv_splash_item = (ImageView) view.findViewById(R.id.iv_splash_item);
            this.tv_splash_item = (TextView) view.findViewById(R.id.tv_splash_item);
        }
    }
}

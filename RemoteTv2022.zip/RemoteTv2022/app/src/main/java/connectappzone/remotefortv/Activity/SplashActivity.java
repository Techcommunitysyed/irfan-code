package connectappzone.remotefortv.Activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.snackbar.Snackbar;
import connectappzone.remotefortv.Adapter.SplashListAdapter;
import connectappzone.remotefortv.Glob;
import connectappzone.remotefortv.MainActivity;
import connectappzone.remotefortv.Model.SplashModel;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.TokanData.CallAPI;
import connectappzone.remotefortv.TokanData.PreferencesUtils;
import connectappzone.remotefortv.TokanData.SendAppToken;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class SplashActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1000;
    static SharedPreferences.Editor editor;
    int counter = 0;
    private boolean dataAvailable = false;
    private long diffMills = 0;
    boolean doubleBackToExitPressedOnce = false;
    private String gm;
    int i = 0;
    /* access modifiers changed from: private */
    public boolean isAlreadyCall = false;
    private ImageView iv_start;
    int j = 0;
    private InterstitialAd mInterstitialAdMob;
    /* access modifiers changed from: private */
    public PreferencesUtils pref;
    /* access modifiers changed from: private */
    public RecyclerView rv_splash_list1;
    /* access modifiers changed from: private */
    public RecyclerView rv_splash_list2;
    /* access modifiers changed from: private */
    public RecyclerView rv_splash_list3;
    private SharedPreferences sp;
    private ArrayList<SplashModel> splashList1 = new ArrayList<>();
    private ArrayList<SplashModel> splashList2 = new ArrayList<>();
    private ArrayList<SplashModel> splashList3 = new ArrayList<>();
    private int totalHours = 0;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_splash);
        getWindow().setFlags(1024, 1024);
        this.mInterstitialAdMob = showAdmobFullAd();
        loadAdmobAd();
        this.counter = 0;
        this.pref = PreferencesUtils.getInstance(this);
        setStoreToken(getString(R.string.app_name));
        bindView();
        setAppInList();
    }

    private void setStoreToken(String str) {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), 0);
        this.sp = sharedPreferences;
        String string = sharedPreferences.getString("gm", "");
        this.gm = string;
        if (this.i == 0 && string.equals("")) {
            SharedPreferences.Editor edit = this.sp.edit();
            edit.putString("gm", "0");
            edit.commit();
            this.gm = this.sp.getString("gm", "");
        }
        if (isOnline()) {
            try {
                if (this.gm.equals("0")) {
                    new SendAppToken(getApplicationContext()).execute(new String[]{str});
                    SharedPreferences.Editor edit2 = this.sp.edit();
                    editor = edit2;
                    edit2.putString("gm", "1");
                    editor.commit();
                }
            } catch (Exception unused) {
            }
        }
    }

    private void bindView() {
        this.rv_splash_list1 = (RecyclerView) findViewById(R.id.rv_splash_list1);
        this.rv_splash_list2 = (RecyclerView) findViewById(R.id.rv_splash_list2);
        this.rv_splash_list3 = (RecyclerView) findViewById(R.id.rv_splash_list3);
        ImageView imageView = (ImageView) findViewById(R.id.iv_start);
        this.iv_start = imageView;
        imageView.setOnClickListener(this);
    }

    /* access modifiers changed from: private */
    public void setAppInList() {
        Calendar instance = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String format = simpleDateFormat.format(instance.getTime());
        String prefString = this.pref.getPrefString(PreferencesUtils.TIME_OF_GET_APP_SPLASH);
        try {
            long time = simpleDateFormat.parse(format).getTime() - simpleDateFormat.parse(prefString).getTime();
            this.diffMills = time;
            this.totalHours = (int) (time / 3600000);
        } catch (Exception e) {
            e.printStackTrace();
            this.totalHours = 0;
        }
        int i2 = this.totalHours;
        if (i2 >= 0 && i2 < 6) {
            showMoreApps();
        } else if (isOnline()) {
            callApiForApplist();
        } else {
            showMoreApps();
        }
    }

    private void showMoreApps() {
        String prefString = this.pref.getPrefString(PreferencesUtils.SPLASH_1_JSON);
        if (!TextUtils.isEmpty(prefString)) {
            try {
                JSONObject jSONObject = new JSONObject(prefString);
                if (jSONObject.optString("ac_link") != null && !TextUtils.isEmpty(jSONObject.optString("ac_link"))) {
                    Glob.acc_link = jSONObject.optString("ac_link");
                }
                if (jSONObject.optString("privacy_link") != null && !TextUtils.isEmpty(jSONObject.optString("privacy_link"))) {
                    Glob.privacy_link = jSONObject.optString("privacy_link");
                }
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                if (jSONArray.length() != 0) {
                    this.dataAvailable = true;
                    for (int i2 = 0; i2 < jSONArray.length() / 3; i2++) {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                        String string = jSONObject2.getString("application_name");
                        String string2 = jSONObject2.getString("application_link");
                        String string3 = jSONObject2.getString("icon");
                        ArrayList<SplashModel> arrayList = this.splashList1;
                        arrayList.add(new SplashModel("http://appbankstudio.in/appbank/images/" + string3, string, string2));
                    }
                    final SplashListAdapter splashListAdapter = new SplashListAdapter(this, this.splashList1);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            SplashActivity.this.rv_splash_list1.setLayoutManager(new LinearLayoutManager(SplashActivity.this, 0, false));
                            SplashActivity.this.rv_splash_list1.setAdapter(splashListAdapter);
                        }
                    });
                    for (int length = jSONArray.length() / 3; length < (jSONArray.length() / 3) * 2; length++) {
                        JSONObject jSONObject3 = jSONArray.getJSONObject(length);
                        String string4 = jSONObject3.getString("application_name");
                        String string5 = jSONObject3.getString("application_link");
                        String string6 = jSONObject3.getString("icon");
                        ArrayList<SplashModel> arrayList2 = this.splashList2;
                        arrayList2.add(new SplashModel("http://appbankstudio.in/appbank/images/" + string6, string4, string5));
                    }
                    final SplashListAdapter splashListAdapter2 = new SplashListAdapter(this, this.splashList2);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            SplashActivity.this.rv_splash_list2.setLayoutManager(new LinearLayoutManager(SplashActivity.this, 0, false));
                            SplashActivity.this.rv_splash_list2.setAdapter(splashListAdapter2);
                        }
                    });
                    for (int length2 = (jSONArray.length() / 3) * 2; length2 < jSONArray.length(); length2++) {
                        JSONObject jSONObject4 = jSONArray.getJSONObject(length2);
                        String string7 = jSONObject4.getString("application_name");
                        String string8 = jSONObject4.getString("application_link");
                        String string9 = jSONObject4.getString("icon");
                        ArrayList<SplashModel> arrayList3 = this.splashList3;
                        arrayList3.add(new SplashModel("http://appbankstudio.in/appbank/images/" + string9, string7, string8));
                    }
                    final SplashListAdapter splashListAdapter3 = new SplashListAdapter(this, this.splashList3);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            SplashActivity.this.rv_splash_list3.setLayoutManager(new LinearLayoutManager(SplashActivity.this, 0, false));
                            SplashActivity.this.rv_splash_list3.setAdapter(splashListAdapter3);
                        }
                    });
                } else if (!this.isAlreadyCall) {
                    callApiForApplist();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            callApiForApplist();
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    private void callApiForApplist() {
        new Thread(new Runnable() {
            public void run() {
                CallAPI.callGet("", "splash_9/" + Glob.appID, false, new CallAPI.ResultCallBack() {
                    public void onCancelled() {
                    }

                    public void onFailure(int i, String str) {
                    }

                    public void onSuccess(int i, String str) {
                        boolean unused = SplashActivity.this.isAlreadyCall = true;
                        PrintStream printStream = System.out;
                        printStream.println("Response-" + str);
                        PrintStream printStream2 = System.out;
                        printStream2.println("Code-" + i);
                        SplashActivity.this.pref.setPrefString(PreferencesUtils.SPLASH_1_JSON, str);
                        SplashActivity.this.setTimeForApp();
                        SplashActivity.this.setAppInList();
                    }
                });
            }
        }).start();
    }

    /* access modifiers changed from: package-private */
    public void setTimeForApp() {
        this.pref.setPrefString(PreferencesUtils.TIME_OF_GET_APP_SPLASH, new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime()));
    }

    public void onClick(View view) {
        if (view.getId() == R.id.iv_start) {
            if (Build.VERSION.SDK_INT < 23) {
                callnextactivity();
            } else if (checkAndRequestPermissions()) {
                callnextactivity();
            }
        }
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        if (i2 == 1000) {
            HashMap hashMap = new HashMap();
            hashMap.put("android.permission.WRITE_EXTERNAL_STORAGE", 0);
            hashMap.put("android.permission.READ_EXTERNAL_STORAGE", 0);
            if (iArr.length > 0) {
                for (int i3 = 0; i3 < strArr.length; i3++) {
                    hashMap.put(strArr[i3], Integer.valueOf(iArr[i3]));
                }
                if (((Integer) hashMap.get("android.permission.WRITE_EXTERNAL_STORAGE")).intValue() == 0 && ((Integer) hashMap.get("android.permission.READ_EXTERNAL_STORAGE")).intValue() == 0) {
                    callnextactivity();
                } else if (ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.WRITE_EXTERNAL_STORAGE") || ActivityCompat.shouldShowRequestPermissionRationale(this, "android.permission.READ_EXTERNAL_STORAGE")) {
                    showDialogOK("Permission required for this app", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialogInterface, int i) {
                            if (i == -1) {
                                boolean unused = SplashActivity.this.checkAndRequestPermissions();
                            }
                        }
                    });
                } else {
                    Toast.makeText(this, "Go to settings and enable permissions", 0).show();
                }
            }
        }
    }

    private void showDialogOK(String str, DialogInterface.OnClickListener onClickListener) {
        new AlertDialog.Builder(this).setMessage((CharSequence) str).setPositiveButton((CharSequence) "OK", onClickListener).setNegativeButton((CharSequence) "Cancel", onClickListener).create().show();
    }

    private void callnextactivity() {
        startActivity(new Intent(this, MainActivity.class));
        showAdmobInterstitial();
    }

    private InterstitialAd showAdmobFullAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
            }

            public void onAdOpened() {
            }

            public void onAdClosed() {
                SplashActivity.this.loadAdmobAd();
            }
        });
        return interstitialAd;
    }

    /* access modifiers changed from: private */
    public void loadAdmobAd() {
        this.mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
    }

    private void showAdmobInterstitial() {
        InterstitialAd interstitialAd = this.mInterstitialAdMob;
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            this.mInterstitialAdMob.show();
        }
    }

    /* access modifiers changed from: private */
    public boolean checkAndRequestPermissions() {
        int checkSelfPermission = ContextCompat.checkSelfPermission(this, "android.permission.WRITE_EXTERNAL_STORAGE");
        int checkSelfPermission2 = ContextCompat.checkSelfPermission(this, "android.permission.READ_EXTERNAL_STORAGE");
        ArrayList arrayList = new ArrayList();
        if (checkSelfPermission != 0) {
            arrayList.add("android.permission.WRITE_EXTERNAL_STORAGE");
        }
        if (checkSelfPermission2 != 0) {
            arrayList.add("android.permission.READ_EXTERNAL_STORAGE");
        }
        if (arrayList.isEmpty()) {
            return true;
        }
        ActivityCompat.requestPermissions(this, (String[]) arrayList.toArray(new String[arrayList.size()]), 1000);
        return false;
    }

    public void onBackPressed() {
        String prefString = this.pref.getPrefString(PreferencesUtils.EXIT_JSON);
        if (isOnline()) {
            if ((TextUtils.isEmpty(prefString) && !isOnline()) || !this.dataAvailable) {
                if (this.doubleBackToExitPressedOnce) {
                    finish();
                    super.onBackPressed();
                }
                this.doubleBackToExitPressedOnce = true;
                Snackbar make = Snackbar.make((View) this.iv_start, (CharSequence) "click BACK again to exit", -1);
                ((TextView) make.getView().findViewById(R.id.snackbar_text)).setTextColor(-1);
                make.show();
                Toast.makeText(this, "click BACK again to exit", 1);
                new Handler().postDelayed(new Runnable() {
                    public void run() {
                        SplashActivity.this.doubleBackToExitPressedOnce = false;
                    }
                }, 2000);
            } else if (this.counter == 0) {
                startActivity(new Intent(this, BackActivity.class).addFlags(335544320));
                finish();
            }
        } else if ((!TextUtils.isEmpty(prefString) || isOnline()) && this.dataAvailable) {
            startActivity(new Intent(this, BackActivity.class).addFlags(335544320));
            finish();
        } else {
            if (this.doubleBackToExitPressedOnce) {
                finish();
                super.onBackPressed();
            }
            this.doubleBackToExitPressedOnce = true;
            Snackbar make2 = Snackbar.make((View) this.iv_start, (CharSequence) "click BACK again to exit", -1);
            ((TextView) make2.getView().findViewById(R.id.snackbar_text)).setTextColor(-1);
            make2.show();
            Toast.makeText(this, "click BACK again to exit", 1);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    SplashActivity.this.doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        }
    }
}

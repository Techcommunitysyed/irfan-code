package connectappzone.remotefortv.Activity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.helper.Constant;

public class SecondActivity extends Activity {
    SharedPreferences.Editor editor;
    ImageView imgcon1;
    ImageView imgcon2;
    ImageView imgcon3;
    LinearLayout lycancel;
    LinearLayout lycon1;
    LinearLayout lycon2;
    LinearLayout lycon3;
    LinearLayout lyok;
    /* access modifiers changed from: private */
    public UnifiedNativeAd nativeAd;
    SharedPreferences prefs;

    private void refreshAd() {
        AdLoader.Builder builder = new AdLoader.Builder((Context) this, getString(R.string.Admob_Native_Advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (SecondActivity.this.nativeAd != null) {
                    SecondActivity.this.nativeAd.destroy();
                }
                UnifiedNativeAd unused = SecondActivity.this.nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = (FrameLayout) SecondActivity.this.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView unifiedNativeAdView = (UnifiedNativeAdView) SecondActivity.this.getLayoutInflater().inflate(R.layout.ad_unified, (ViewGroup) null);
                SecondActivity.this.populateUnifiedNativeAdView(unifiedNativeAd, unifiedNativeAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(unifiedNativeAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    /* access modifiers changed from: private */
    public void populateUnifiedNativeAdView(UnifiedNativeAd unifiedNativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        unifiedNativeAdView.setMediaView((MediaView) unifiedNativeAdView.findViewById(R.id.ad_media));
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setIconView(unifiedNativeAdView.findViewById(R.id.ad_app_icon));
        unifiedNativeAdView.setPriceView(unifiedNativeAdView.findViewById(R.id.ad_price));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        unifiedNativeAdView.setAdvertiserView(unifiedNativeAdView.findViewById(R.id.ad_advertiser));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(4);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(unifiedNativeAd.getBody());
        }
        if (unifiedNativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(4);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(0);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }
        if (unifiedNativeAd.getIcon() == null) {
            unifiedNativeAdView.getIconView().setVisibility(8);
        } else {
            ((ImageView) unifiedNativeAdView.getIconView()).setImageDrawable(unifiedNativeAd.getIcon().getDrawable());
            unifiedNativeAdView.getIconView().setVisibility(0);
        }
        if (unifiedNativeAd.getPrice() == null) {
            unifiedNativeAdView.getPriceView().setVisibility(4);
        } else {
            unifiedNativeAdView.getPriceView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getPriceView()).setText(unifiedNativeAd.getPrice());
        }
        if (unifiedNativeAd.getStore() == null) {
            unifiedNativeAdView.getStoreView().setVisibility(4);
        } else {
            unifiedNativeAdView.getStoreView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(unifiedNativeAd.getStore());
        }
        if (unifiedNativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(4);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(unifiedNativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(0);
        }
        if (unifiedNativeAd.getAdvertiser() == null) {
            unifiedNativeAdView.getAdvertiserView().setVisibility(4);
        } else {
            ((TextView) unifiedNativeAdView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
            unifiedNativeAdView.getAdvertiserView().setVisibility(0);
        }
        unifiedNativeAdView.setNativeAd(unifiedNativeAd);
        VideoController videoController = unifiedNativeAd.getVideoController();
        if (videoController.hasVideoContent()) {
            videoController.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        UnifiedNativeAd unifiedNativeAd = this.nativeAd;
        if (unifiedNativeAd != null) {
            unifiedNativeAd.destroy();
        }
        super.onDestroy();
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_second);
        refreshAd();
        this.editor = getSharedPreferences(Constant.preferences_name, 0).edit();
        this.prefs = getSharedPreferences(Constant.preferences_name, 0);
        this.lycon1 = (LinearLayout) findViewById(R.id.lycon1);
        this.lycon2 = (LinearLayout) findViewById(R.id.lycon2);
        this.lycon3 = (LinearLayout) findViewById(R.id.lycon3);
        this.lyok = (LinearLayout) findViewById(R.id.lyok);
        this.lycancel = (LinearLayout) findViewById(R.id.lycancel);
        this.imgcon1 = (ImageView) findViewById(R.id.imgcon1);
        this.imgcon2 = (ImageView) findViewById(R.id.imgcon2);
        this.imgcon3 = (ImageView) findViewById(R.id.imgcon3);
        String string = this.prefs.getString(Constant.connection_mode, "Connection");
        if (string.equalsIgnoreCase("Connection") || string.equalsIgnoreCase("ip")) {
            setvisiblity(this.imgcon1, this.imgcon2, this.imgcon3);
        } else if (string.equalsIgnoreCase("ir")) {
            setvisiblity(this.imgcon2, this.imgcon1, this.imgcon3);
        } else if (string.equalsIgnoreCase("wifi")) {
            setvisiblity(this.imgcon3, this.imgcon1, this.imgcon2);
        }
        this.lycon1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity secondActivity = SecondActivity.this;
                secondActivity.setvisiblity(secondActivity.imgcon1, SecondActivity.this.imgcon2, SecondActivity.this.imgcon3);
                SecondActivity.this.editor.putString(Constant.connection_mode, "ip");
                SecondActivity.this.editor.commit();
            }
        });
        this.lycon2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity secondActivity = SecondActivity.this;
                secondActivity.setvisiblity(secondActivity.imgcon2, SecondActivity.this.imgcon1, SecondActivity.this.imgcon3);
                SecondActivity.this.editor.putString(Constant.connection_mode, "ir");
                SecondActivity.this.editor.commit();
            }
        });
        this.lycon3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity secondActivity = SecondActivity.this;
                secondActivity.setvisiblity(secondActivity.imgcon3, SecondActivity.this.imgcon1, SecondActivity.this.imgcon2);
                SecondActivity.this.editor.putString(Constant.connection_mode, "wifi");
                SecondActivity.this.editor.commit();
            }
        });
        this.lyok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (SecondActivity.this.prefs.getInt(Constant.flag_con, 0) == 1) {
                    SecondActivity.this.setResult(-1, new Intent());
                } else {
                    SecondActivity.this.startActivity(new Intent(SecondActivity.this, ConnectingSycActivity.class));
                }
                SecondActivity.this.finish();
            }
        });
        this.lycancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SecondActivity.this.finish();
            }
        });
    }

    public void setvisiblity(ImageView imageView, ImageView imageView2, ImageView imageView3) {
        imageView.setBackgroundResource(R.mipmap.radio_on);
        imageView2.setBackgroundResource(R.mipmap.radio_off);
        imageView3.setBackgroundResource(R.mipmap.radio_off);
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }
}

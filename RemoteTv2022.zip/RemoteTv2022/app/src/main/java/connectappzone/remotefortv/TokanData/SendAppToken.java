package connectappzone.remotefortv.TokanData;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import connectappzone.remotefortv.Glob;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import org.apache.http.HttpResponse;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONObject;

public class SendAppToken extends AsyncTask<String, Void, Void> {
    int Scode;
    Context c;
    InputStream in;
    JSONObject jmainobj;
    private String url_g = Glob.GSM_link;

    public SendAppToken(Context context) {
        this.c = context;
    }

    /* access modifiers changed from: protected */
    public Void doInBackground(String... strArr) {
        String str = strArr[0];
        Log.i("Token", str);
        DefaultHttpClient defaultHttpClient = new DefaultHttpClient();
        HttpPost httpPost = new HttpPost(this.url_g);
        try {
            ArrayList arrayList = new ArrayList();
            arrayList.add(new BasicNameValuePair("app_id", Glob.appID + ""));
            arrayList.add(new BasicNameValuePair(PreferencesUtils.DEVICE_TOKEN, str));
            httpPost.setEntity(new UrlEncodedFormEntity(arrayList));
            HttpResponse execute = defaultHttpClient.execute(httpPost);
            this.Scode = execute.getStatusLine().getStatusCode();
            try {
                this.in = execute.getEntity().getContent();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(this.in, "iso-8859-1"), 8);
                StringBuilder sb = new StringBuilder();
                while (true) {
                    String readLine = bufferedReader.readLine();
                    if (readLine != null) {
                        sb.append(readLine);
                        PrintStream printStream = System.out;
                        printStream.println("Tokan Successfullyy..........!!!!" + sb);
                    } else {
                        this.in.close();
                        this.jmainobj = new JSONObject(sb.toString());
                        return null;
                    }
                }
            } catch (Exception unused) {
                return null;
            }
        } catch (Exception e) {
            Log.e("Fail 1", e.toString());
            return null;
        }
    }

    /* access modifiers changed from: protected */
    public void onPostExecute(Void voidR) {
        super.onPostExecute(voidR);
    }
}

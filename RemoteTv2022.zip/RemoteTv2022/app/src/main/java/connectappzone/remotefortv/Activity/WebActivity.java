package connectappzone.remotefortv.Activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import connectappzone.remotefortv.Glob;
import connectappzone.remotefortv.R;

public class WebActivity extends AppCompatActivity {
    private WebView webPrivacyPolicy;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_web);
        WebView webView = (WebView) findViewById(R.id.wvPrivacyPolicy);
        this.webPrivacyPolicy = webView;
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        this.webPrivacyPolicy.setWebViewClient(new WebViewClient() {
            public boolean shouldOverrideUrlLoading(WebView webView, String str) {
                if (str.startsWith("http:") || str.startsWith("https:")) {
                    return false;
                }
                WebActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(str)));
                return true;
            }

            public void onReceivedError(WebView webView, int i, String str, String str2) {
                Toast.makeText(WebActivity.this, str, 0).show();
            }
        });
        this.webPrivacyPolicy.loadUrl(Glob.privacy_link);
    }

    public void onBackPressed() {
        finish();
    }
}

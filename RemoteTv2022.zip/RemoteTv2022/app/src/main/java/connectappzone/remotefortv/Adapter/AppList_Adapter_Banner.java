package connectappzone.remotefortv.Adapter;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import connectappzone.remotefortv.Model.SplashModel;
import connectappzone.remotefortv.R;
import java.util.ArrayList;

public class AppList_Adapter_Banner extends BaseAdapter {
    /* access modifiers changed from: private */
    public Activity activity;
    ArrayList<SplashModel> exitAppList = new ArrayList<>();
    SparseBooleanArray mSparseBooleanArray;

    public long getItemId(int i) {
        return (long) i;
    }

    public AppList_Adapter_Banner(Activity activity2, ArrayList<SplashModel> arrayList) {
        this.activity = activity2;
        this.exitAppList = arrayList;
        this.mSparseBooleanArray = new SparseBooleanArray(arrayList.size());
    }

    public int getCount() {
        return this.exitAppList.size();
    }

    public Object getItem(int i) {
        return this.exitAppList.get(i);
    }

    public View getView(final int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = LayoutInflater.from(this.activity).inflate(R.layout.list_appstore1, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.imgIcon = (ImageView) view.findViewById(R.id.imglogo);
            viewHolder.txtname = (TextView) view.findViewById(R.id.txtname);
            viewHolder.tv_install = (TextView) view.findViewById(R.id.tv_install);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.txtname.setText(this.exitAppList.get(i).getAppName());
        viewHolder.txtname.setSelected(true);
        ((RequestBuilder) ((RequestBuilder) Glide.with(this.activity).load(this.exitAppList.get(i).getAppUrl()).centerCrop()).placeholder((int) R.mipmap.ic_launcher)).into(viewHolder.imgIcon);
        viewHolder.tv_install.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                try {
                    AppList_Adapter_Banner.this.activity.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(AppList_Adapter_Banner.this.exitAppList.get(i).getAppLink())));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(AppList_Adapter_Banner.this.activity, "You don't have Google Play installed", 1).show();
                }
            }
        });
        return view;
    }

    static class ViewHolder {
        ImageView imgIcon;
        TextView tv_install;
        TextView txtname;

        ViewHolder() {
        }
    }
}

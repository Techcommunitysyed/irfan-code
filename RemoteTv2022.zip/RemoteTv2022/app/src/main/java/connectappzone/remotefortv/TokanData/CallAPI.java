package connectappzone.remotefortv.TokanData;

import android.util.Log;
import com.bumptech.glide.load.Key;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;

public class CallAPI {
    static final int CONNECTION_TIME_OUT = 20000;
    public static String strURL = "http://appbankstudio.in/appbank/service/app_link";

    public interface ResultCallBack {
        void onCancelled();

        void onFailure(int i, String str);

        void onSuccess(int i, String str);
    }

    private static String getResponseText(InputStream inputStream) {
        StringBuilder sb = new StringBuilder();
        if (inputStream != null) {
            BufferedReader bufferedReader = null;
            try {
                BufferedReader bufferedReader2 = new BufferedReader(new InputStreamReader(inputStream));
                while (true) {
                    try {
                        int read = bufferedReader2.read();
                        if (read != -1) {
                            sb.append((char) read);
                        } else {
                            break;
                        }
                    } catch (IOException e2) {
                        e2 = e2;
                        bufferedReader = bufferedReader2;
                        StringBuilder sb2 = new StringBuilder();
                        sb2.append("Message = ");
                        sb2.append(e2.getMessage());
                        sb2.append("Cause = ");
                        sb2.append(e2.getCause());
                        e2.printStackTrace();
                        if (bufferedReader != null) {
                            try {
                                bufferedReader.close();
                                inputStream.close();
                            } catch (IOException e3) {
                                e3 = e3;
                                e3.printStackTrace();
                                sb = new StringBuilder();
                                sb.append("Message = ");
                                sb.append(e3.getMessage());
                                sb.append("Cause = ");
                                sb.append(e3.getCause());
                                return sb.toString();
                            }
                        }
                        sb = sb2;
                        return sb.toString();
                    } catch (Throwable th) {
                        th = th;
                        bufferedReader = bufferedReader2;
                        if (bufferedReader != null) {
                            try {
                                bufferedReader.close();
                                inputStream.close();
                            } catch (IOException e4) {
                                e4.printStackTrace();
                                StringBuilder sb3 = new StringBuilder();
                                sb3.append("Message = ");
                                sb3.append(e4.getMessage());
                                sb3.append("Cause = ");
                                sb3.append(e4.getCause());
                            }
                        }
                        throw th;
                    }
                }
                bufferedReader2.close();
                inputStream.close();
            } catch (Throwable th2) {
                th2 = th2;
            }
        }
        return sb.toString();
    }

    public static void callGet(String str, String str2, boolean z, ResultCallBack resultCallBack) {
        HttpURLConnection httpURLConnection = null;
        try {
            URL url = new URL(strURL + "/" + str2);
            StringBuilder sb = new StringBuilder();
            sb.append("callGet: ");
            sb.append(str2);
            Log.i("CallAPI", sb.toString());
            HttpURLConnection httpURLConnection2 = (HttpURLConnection) url.openConnection();
            try {
                httpURLConnection2.setConnectTimeout(CONNECTION_TIME_OUT);
                if (z) {
                    httpURLConnection2.setRequestProperty("Authorization", "bearer " + str);
                }
                httpURLConnection2.setUseCaches(false);
                httpURLConnection2.setRequestMethod("GET");
                int responseCode = httpURLConnection2.getResponseCode();
                if (responseCode == 200) {
                    String responseText = getResponseText(httpURLConnection2.getInputStream());
                    httpURLConnection2.disconnect();
                    resultCallBack.onSuccess(responseCode, responseText);
                    return;
                }
                String responseText2 = getResponseText(httpURLConnection2.getErrorStream());
                httpURLConnection2.disconnect();
                resultCallBack.onFailure(responseCode, responseText2);
            } catch (Exception e) {
                e = e;
                httpURLConnection = httpURLConnection2;
                e.printStackTrace();
                resultCallBack.onFailure(0, getResponseText(httpURLConnection.getErrorStream()));
            }
        } catch (Exception e2) {
            e2 = e2;
        }
    }

    public static void callPost(String str, String str2, String str3, boolean z, ResultCallBack resultCallBack) {
        HttpURLConnection httpURLConnection = null;
        HttpURLConnection httpURLConnection2 = null;
        try {
            httpURLConnection = (HttpURLConnection) new URL(strURL + "/" + str2).openConnection();
        } catch (Exception e) {
            e = e;
        }
        try {
            httpURLConnection.setConnectTimeout(CONNECTION_TIME_OUT);
            if (z) {
                httpURLConnection.setRequestProperty("Authorization", "bearer " + str);
            }
            httpURLConnection.setRequestProperty("Content-Type", "application/json");
            httpURLConnection.setRequestProperty("Content-Language", "en-US");
            httpURLConnection.setUseCaches(false);
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setDoOutput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, Key.STRING_CHARSET_NAME));
            bufferedWriter.write(str3);
            bufferedWriter.flush();
            bufferedWriter.close();
            outputStream.flush();
            outputStream.close();
            int responseCode = httpURLConnection.getResponseCode();
            if (responseCode == 200) {
                String responseText = getResponseText(httpURLConnection.getInputStream());
                httpURLConnection.disconnect();
                resultCallBack.onSuccess(responseCode, responseText);
                return;
            }
            String responseText2 = getResponseText(httpURLConnection.getErrorStream());
            httpURLConnection.disconnect();
            resultCallBack.onFailure(responseCode, responseText2);
        } catch (Exception e2) {
            e2 = e2;
            httpURLConnection2 = httpURLConnection;
            e2.printStackTrace();
            resultCallBack.onFailure(0, getResponseText(httpURLConnection2.getErrorStream()));
        }
    }
}
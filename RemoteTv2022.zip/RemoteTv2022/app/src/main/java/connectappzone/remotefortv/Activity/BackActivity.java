package connectappzone.remotefortv.Activity;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.ColorDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdLoader;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.VideoController;
import com.google.android.gms.ads.VideoOptions;
import com.google.android.gms.ads.formats.MediaView;
import com.google.android.gms.ads.formats.NativeAdOptions;
import com.google.android.gms.ads.formats.UnifiedNativeAd;
import com.google.android.gms.ads.formats.UnifiedNativeAdView;
import connectappzone.remotefortv.Adapter.AppList_Adapter;
import connectappzone.remotefortv.Adapter.AppList_Adapter_Banner;
import connectappzone.remotefortv.Glob;
import connectappzone.remotefortv.MainActivity;
import connectappzone.remotefortv.Model.SplashModel;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.TokanData.CallAPI;
import connectappzone.remotefortv.TokanData.PreferencesUtils;
import connectappzone.remotefortv.View.ExpandableGridView;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class BackActivity extends AppCompatActivity {
    ExpandableGridView app_list;
    ExpandableGridView app_list1;
    /* access modifiers changed from: private */
    public Dialog dialog;
    /* access modifiers changed from: private */
    public ArrayList<SplashModel> exitList1 = new ArrayList<>();
    /* access modifiers changed from: private */
    public ArrayList<SplashModel> exitList2 = new ArrayList<>();
    /* access modifiers changed from: private */
    public boolean isAlreadyCall = false;
    private InterstitialAd mInterstitialAdMob;
    /* access modifiers changed from: private */
    public UnifiedNativeAd nativeAd;
    /* access modifiers changed from: private */
    public PreferencesUtils pref;
    private int totalHours;
    private TextView txt_dia;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_back);
        getWindow().setFlags(1024, 1024);
        this.pref = PreferencesUtils.getInstance(this);
        ExpandableGridView expandableGridView = (ExpandableGridView) findViewById(R.id.gvAppList);
        this.app_list = expandableGridView;
        expandableGridView.setExpanded(true);
        ExpandableGridView expandableGridView2 = (ExpandableGridView) findViewById(R.id.gvAppList1);
        this.app_list1 = expandableGridView2;
        expandableGridView2.setExpanded(true);
        setAppInList();
        this.mInterstitialAdMob = showAdmobFullAd();
        loadAdmobAd();
    }

    private void moreapp() {
        try {
            startActivity(new Intent("android.intent.action.VIEW", Uri.parse(Glob.acc_link)));
        } catch (ActivityNotFoundException unused) {
            Toast.makeText(this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
        }
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService("connectivity")).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    private void callApiForApplist() {
        new Thread(new Runnable() {
            public void run() {
                CallAPI.callGet("", "exit_9/" + Glob.appID, false, new CallAPI.ResultCallBack() {
                    public void onCancelled() {
                    }

                    public void onFailure(int i, String str) {
                    }

                    public void onSuccess(int i, String str) {
                        boolean unused = BackActivity.this.isAlreadyCall = true;
                        PrintStream printStream = System.out;
                        printStream.println("Response-" + str);
                        PrintStream printStream2 = System.out;
                        printStream2.println("Code-" + i);
                        BackActivity.this.pref.setPrefString(PreferencesUtils.EXIT_JSON, str);
                        BackActivity.this.setTimeForApp();
                        BackActivity.this.setAppInList();
                    }
                });
            }
        }).start();
    }

    /* access modifiers changed from: private */
    public void setAppInList() {
        Calendar instance = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String format = simpleDateFormat.format(instance.getTime());
        String prefString = this.pref.getPrefString(PreferencesUtils.TIME_OF_GET_APP_EXIT);
        try {
            this.totalHours = (int) ((simpleDateFormat.parse(format).getTime() - simpleDateFormat.parse(prefString).getTime()) / 3600000);
        } catch (Exception e) {
            e.printStackTrace();
            this.totalHours = 0;
        }
        int i = this.totalHours;
        if (i >= 0 && i < 6) {
            showMoreApps();
        } else if (isOnline()) {
            callApiForApplist();
        } else {
            showMoreApps();
        }
    }

    private void showMoreApps() {
        int i;
        String prefString = this.pref.getPrefString(PreferencesUtils.EXIT_JSON);
        if (!TextUtils.isEmpty(prefString)) {
            try {
                JSONArray jSONArray = new JSONObject(prefString).getJSONArray("data");
                if (jSONArray.length() > 0) {
                    this.exitList1.clear();
                    this.exitList2.clear();
                    int i2 = 0;
                    while (true) {
                        if (i2 >= 15) {
                            break;
                        }
                        JSONObject jSONObject = jSONArray.getJSONObject(i2);
                        String string = jSONObject.getString("application_name");
                        String string2 = jSONObject.getString("application_link");
                        String string3 = jSONObject.getString("icon");
                        ArrayList<SplashModel> arrayList = this.exitList1;
                        arrayList.add(new SplashModel("http://appbankstudio.in/appbank/images/" + string3, string, string2));
                        i2++;
                    }
                    for (i = 15; i < jSONArray.length(); i++) {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i);
                        String string4 = jSONObject2.getString("application_name");
                        String string5 = jSONObject2.getString("application_link");
                        String string6 = jSONObject2.getString("icon");
                        PrintStream printStream = System.out;
                        printStream.println("photo_name -" + string4);
                        PrintStream printStream2 = System.out;
                        printStream2.println("photo_link -" + string5);
                        PrintStream printStream3 = System.out;
                        printStream3.println("photo_icon -" + string6);
                        ArrayList<SplashModel> arrayList2 = this.exitList2;
                        arrayList2.add(new SplashModel("http://appbankstudio.in/appbank/images/" + string6, string4, string5));
                    }
                    final AppList_Adapter appList_Adapter = new AppList_Adapter(this, this.exitList1);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            BackActivity.this.app_list.setAdapter(appList_Adapter);
                        }
                    });
                    final AppList_Adapter_Banner appList_Adapter_Banner = new AppList_Adapter_Banner(this, this.exitList2);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            BackActivity.this.app_list1.setAdapter(appList_Adapter_Banner);
                        }
                    });
                } else if (!this.isAlreadyCall) {
                    callApiForApplist();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            callApiForApplist();
        }
        this.app_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    BackActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(((SplashModel) BackActivity.this.exitList1.get(i)).getAppLink())));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(BackActivity.this, "You don't have Google Play installed", 1).show();
                }
            }
        });
        this.app_list1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    BackActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(((SplashModel) BackActivity.this.exitList2.get(i)).getAppLink())));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(BackActivity.this, "You don't have Google Play installed", 1).show();
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void setTimeForApp() {
        this.pref.setPrefString(PreferencesUtils.TIME_OF_GET_APP_EXIT, new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime()));
    }

    public void onBackPressed() {
        if (isOnline()) {
            InterstitialAd interstitialAd = this.mInterstitialAdMob;
            if (interstitialAd == null || !interstitialAd.isLoaded()) {
                opendialogexit();
            } else {
                this.mInterstitialAdMob.show();
            }
        } else {
            opendialogexit();
        }
    }

    private InterstitialAd showAdmobFullAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
            }

            public void onAdOpened() {
            }

            public void onAdClosed() {
                BackActivity.this.loadAdmobAd();
                BackActivity.this.opendialogexit();
            }
        });
        return interstitialAd;
    }

    /* access modifiers changed from: private */
    public void loadAdmobAd() {
        this.mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
    }

    /* access modifiers changed from: private */
    public void opendialogexit() {
        Dialog dialog2 = new Dialog(this, 16973840);
        this.dialog = dialog2;
        dialog2.requestWindowFeature(1);
        this.dialog.setContentView(R.layout.customdailog2);
        this.dialog.setCancelable(false);
        this.dialog.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        refreshAd();
        this.txt_dia = (TextView) this.dialog.findViewById(R.id.txt_dia);
        TextView textView = (TextView) this.dialog.findViewById(R.id.btn_no);
        textView.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Glob.onviewtouch(BackActivity.this, view);
                return false;
            }
        });
        textView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BackActivity.this.dialog.dismiss();
                BackActivity.this.startActivity(new Intent(BackActivity.this, MainActivity.class));
            }
        });
        TextView textView2 = (TextView) this.dialog.findViewById(R.id.btn_yes);
        textView2.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                Glob.onviewtouch(BackActivity.this, view);
                return false;
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                BackActivity.this.setResult(0);
                BackActivity.this.dialog.dismiss();
                BackActivity.this.finish();
                BackActivity.this.finishAffinity();
            }
        });
        this.dialog.show();
    }

    private void refreshAd() {
        AdLoader.Builder builder = new AdLoader.Builder((Context) this, getString(R.string.Admob_Native_Advance));
        builder.forUnifiedNativeAd(new UnifiedNativeAd.OnUnifiedNativeAdLoadedListener() {
            public void onUnifiedNativeAdLoaded(UnifiedNativeAd unifiedNativeAd) {
                if (BackActivity.this.nativeAd != null) {
                    BackActivity.this.nativeAd.destroy();
                }
                UnifiedNativeAd unused = BackActivity.this.nativeAd = unifiedNativeAd;
                FrameLayout frameLayout = (FrameLayout) BackActivity.this.dialog.findViewById(R.id.fl_adplaceholder);
                UnifiedNativeAdView unifiedNativeAdView = (UnifiedNativeAdView) BackActivity.this.getLayoutInflater().inflate(R.layout.ad_unified, (ViewGroup) null);
                BackActivity.this.populateUnifiedNativeAdView(unifiedNativeAd, unifiedNativeAdView);
                frameLayout.removeAllViews();
                frameLayout.addView(unifiedNativeAdView);
            }
        });
        builder.withNativeAdOptions(new NativeAdOptions.Builder().setVideoOptions(new VideoOptions.Builder().build()).build());
        builder.withAdListener(new AdListener() {
            public void onAdFailedToLoad(int i) {
            }
        }).build().loadAd(new AdRequest.Builder().build());
    }

    /* access modifiers changed from: private */
    public void populateUnifiedNativeAdView(UnifiedNativeAd unifiedNativeAd, UnifiedNativeAdView unifiedNativeAdView) {
        unifiedNativeAdView.setMediaView((MediaView) unifiedNativeAdView.findViewById(R.id.ad_media));
        unifiedNativeAdView.setHeadlineView(unifiedNativeAdView.findViewById(R.id.ad_headline));
        unifiedNativeAdView.setBodyView(unifiedNativeAdView.findViewById(R.id.ad_body));
        unifiedNativeAdView.setCallToActionView(unifiedNativeAdView.findViewById(R.id.ad_call_to_action));
        unifiedNativeAdView.setIconView(unifiedNativeAdView.findViewById(R.id.ad_app_icon));
        unifiedNativeAdView.setPriceView(unifiedNativeAdView.findViewById(R.id.ad_price));
        unifiedNativeAdView.setStarRatingView(unifiedNativeAdView.findViewById(R.id.ad_stars));
        unifiedNativeAdView.setStoreView(unifiedNativeAdView.findViewById(R.id.ad_store));
        unifiedNativeAdView.setAdvertiserView(unifiedNativeAdView.findViewById(R.id.ad_advertiser));
        ((TextView) unifiedNativeAdView.getHeadlineView()).setText(unifiedNativeAd.getHeadline());
        if (unifiedNativeAd.getBody() == null) {
            unifiedNativeAdView.getBodyView().setVisibility(4);
        } else {
            unifiedNativeAdView.getBodyView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getBodyView()).setText(unifiedNativeAd.getBody());
        }
        if (unifiedNativeAd.getCallToAction() == null) {
            unifiedNativeAdView.getCallToActionView().setVisibility(4);
        } else {
            unifiedNativeAdView.getCallToActionView().setVisibility(0);
            ((Button) unifiedNativeAdView.getCallToActionView()).setText(unifiedNativeAd.getCallToAction());
        }
        if (unifiedNativeAd.getIcon() == null) {
            unifiedNativeAdView.getIconView().setVisibility(8);
        } else {
            ((ImageView) unifiedNativeAdView.getIconView()).setImageDrawable(unifiedNativeAd.getIcon().getDrawable());
            unifiedNativeAdView.getIconView().setVisibility(0);
        }
        if (unifiedNativeAd.getPrice() == null) {
            unifiedNativeAdView.getPriceView().setVisibility(4);
        } else {
            unifiedNativeAdView.getPriceView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getPriceView()).setText(unifiedNativeAd.getPrice());
        }
        if (unifiedNativeAd.getStore() == null) {
            unifiedNativeAdView.getStoreView().setVisibility(4);
        } else {
            unifiedNativeAdView.getStoreView().setVisibility(0);
            ((TextView) unifiedNativeAdView.getStoreView()).setText(unifiedNativeAd.getStore());
        }
        if (unifiedNativeAd.getStarRating() == null) {
            unifiedNativeAdView.getStarRatingView().setVisibility(4);
        } else {
            ((RatingBar) unifiedNativeAdView.getStarRatingView()).setRating(unifiedNativeAd.getStarRating().floatValue());
            unifiedNativeAdView.getStarRatingView().setVisibility(0);
        }
        if (unifiedNativeAd.getAdvertiser() == null) {
            unifiedNativeAdView.getAdvertiserView().setVisibility(4);
        } else {
            ((TextView) unifiedNativeAdView.getAdvertiserView()).setText(unifiedNativeAd.getAdvertiser());
            unifiedNativeAdView.getAdvertiserView().setVisibility(0);
        }
        unifiedNativeAdView.setNativeAd(unifiedNativeAd);
        VideoController videoController = unifiedNativeAd.getVideoController();
        if (videoController.hasVideoContent()) {
            videoController.setVideoLifecycleCallbacks(new VideoController.VideoLifecycleCallbacks() {
                public void onVideoEnd() {
                    super.onVideoEnd();
                }
            });
        }
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        UnifiedNativeAd unifiedNativeAd = this.nativeAd;
        if (unifiedNativeAd != null) {
            unifiedNativeAd.destroy();
        }
        super.onDestroy();
    }
}

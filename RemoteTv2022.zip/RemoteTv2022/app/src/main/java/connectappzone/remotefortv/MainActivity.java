package connectappzone.remotefortv;

import android.content.ActivityNotFoundException;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.material.snackbar.Snackbar;
import connectappzone.remotefortv.Activity.BackActivity;
import connectappzone.remotefortv.Activity.StartActivity;
import connectappzone.remotefortv.Adapter.AppList_Adapter_splash;
import connectappzone.remotefortv.TokanData.CallAPI;
import connectappzone.remotefortv.TokanData.PreferencesUtils;
import connectappzone.remotefortv.TokanData.SendAppToken;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int MY_REQUEST_CODE = 1;
    private static final int MY_REQUEST_CODE1 = 5;
    private static final int MY_REQUEST_CODE2 = 4;
    private static final int PICK_IMAGE = 100;
    static SharedPreferences.Editor editor;
    public static Bitmap imagebit;
    public static ArrayList<String> listIcon2 = new ArrayList<>();
    public static ArrayList<String> listName2 = new ArrayList<>();
    public static ArrayList<String> listUrl2 = new ArrayList<>();
    public static ArrayList<String> mResults = new ArrayList<>();
    public static Uri myURI;
    public static Bitmap originBitmap;
    public static Uri resultUri;
    private LinearLayout adViewLayout;
    GridView app_list;
    private LinearLayout banner_layout;
    int counter = 0;
    private boolean dataAvailable = false;
    private long diffMills = 0;
    boolean doubleBackToExitPressedOnce = false;
    private String gm;
    int i = 0;
    /* access modifiers changed from: private */
    public boolean isAlreadyCall = false;
    int j = 0;
    ImageView llalbum;
    ImageView llmore;
    private ImageView llmycreation;
    ImageView llstart;
    private InterstitialAd mInterstitialAdMob;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private LinearLayout nativeAdContainer;
    /* access modifiers changed from: private */
    public PreferencesUtils pref;
    private Uri selectedImage;
    private SharedPreferences sp;
    private int totalHours = 0;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_main);
        this.mInterstitialAdMob = showAdmobFullAd();
        loadAdmobAd();
        getWindow().setFlags(1024, 1024);
        mResults.clear();
        this.counter = 0;
        this.pref = PreferencesUtils.getInstance(this);
        setStoreToken(getString(R.string.app_name));
        bind();
        setAppInList();
    }

    private void setStoreToken(String str) {
        SharedPreferences sharedPreferences = getSharedPreferences(getPackageName(), 0);
        this.sp = sharedPreferences;
        String string = sharedPreferences.getString("gm", "");
        this.gm = string;
        if (this.i == 0 && string.equals("")) {
            SharedPreferences.Editor edit = this.sp.edit();
            edit.putString("gm", "0");
            edit.commit();
            this.gm = this.sp.getString("gm", "");
        }
        if (isOnline()) {
            try {
                if (this.gm.equals("0")) {
                    new SendAppToken(getApplicationContext()).execute(new String[]{str});
                    SharedPreferences.Editor edit2 = this.sp.edit();
                    editor = edit2;
                    edit2.putString("gm", "1");
                    editor.commit();
                }
            } catch (Exception unused) {
            }
        }
    }

    private void bind() {
        this.banner_layout = (LinearLayout) findViewById(R.id.banner_layout);
        this.app_list = (GridView) findViewById(R.id.gvMoreApps);
        ImageView imageView = (ImageView) findViewById(R.id.llstart);
        this.llstart = imageView;
        imageView.setOnClickListener(this);
    }

    private void share() {
        Intent intent = new Intent("android.intent.action.SEND");
        intent.setType("image/*");
        intent.putExtra("android.intent.extra.TEXT", Glob.app_name + " Created By :" + Glob.app_link);
        intent.putExtra("android.intent.extra.STREAM", Uri.parse(MediaStore.Images.Media.insertImage(getContentResolver(), BitmapFactory.decodeResource(getResources(), R.drawable.banner), (String) null, (String) null)));
        startActivity(Intent.createChooser(intent, "Share Image using"));
    }

    public boolean isOnline() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnectedOrConnecting();
    }

    private void callApiForApplist() {
        new Thread(new Runnable() {
            public void run() {
                CallAPI.callGet("", "splash_9/" + Glob.appID, false, new CallAPI.ResultCallBack() {
                    public void onCancelled() {
                    }

                    public void onFailure(int i, String str) {
                    }

                    public void onSuccess(int i, String str) {
                        boolean unused = MainActivity.this.isAlreadyCall = true;
                        PrintStream printStream = System.out;
                        printStream.println("Response-" + str);
                        PrintStream printStream2 = System.out;
                        printStream2.println("Code-" + i);
                        MainActivity.this.pref.setPrefString(PreferencesUtils.SPLASH_1_JSON, str);
                        MainActivity.this.setTimeForApp();
                        MainActivity.this.setAppInList();
                    }
                });
            }
        }).start();
    }

    /* access modifiers changed from: private */
    public void setAppInList() {
        Calendar instance = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
        String format = simpleDateFormat.format(instance.getTime());
        String prefString = this.pref.getPrefString(PreferencesUtils.TIME_OF_GET_APP_SPLASH);
        try {
            long time = simpleDateFormat.parse(format).getTime() - simpleDateFormat.parse(prefString).getTime();
            this.diffMills = time;
            this.totalHours = (int) (time / 3600000);
        } catch (Exception e) {
            e.printStackTrace();
            this.totalHours = 0;
        }
        int i2 = this.totalHours;
        if (i2 >= 0 && i2 < 6) {
            showMoreApps();
        } else if (isOnline()) {
            callApiForApplist();
        } else {
            showMoreApps();
        }
    }

    private void showMoreApps() {
        String prefString = this.pref.getPrefString(PreferencesUtils.SPLASH_1_JSON);
        if (!TextUtils.isEmpty(prefString)) {
            try {
                JSONObject jSONObject = new JSONObject(prefString);
                if (jSONObject.optString("ac_link") != null && !TextUtils.isEmpty(jSONObject.optString("ac_link"))) {
                    Glob.acc_link = jSONObject.optString("ac_link");
                }
                if (jSONObject.optString("privacy_link") != null && !TextUtils.isEmpty(jSONObject.optString("privacy_link"))) {
                    Glob.privacy_link = jSONObject.optString("privacy_link");
                    Log.e("privacy", jSONObject.optString("privacy_link"));
                }
                JSONArray jSONArray = jSONObject.getJSONArray("data");
                if (jSONArray.length() != 0) {
                    this.dataAvailable = true;
                    listIcon2.clear();
                    listName2.clear();
                    listUrl2.clear();
                    for (int i2 = 0; i2 < jSONArray.length(); i2++) {
                        JSONObject jSONObject2 = jSONArray.getJSONObject(i2);
                        String string = jSONObject2.getString("application_name");
                        String string2 = jSONObject2.getString("application_link");
                        String string3 = jSONObject2.getString("icon");
                        PrintStream printStream = System.out;
                        printStream.println("photo_name -" + string);
                        PrintStream printStream2 = System.out;
                        printStream2.println("photo_link -" + string2);
                        PrintStream printStream3 = System.out;
                        printStream3.println("photo_icon -" + string3);
                        ArrayList<String> arrayList = listIcon2;
                        arrayList.add("http://appbankstudio.in/appbank/images/" + string3);
                        listName2.add(string);
                        listUrl2.add(string2);
                    }
                    final AppList_Adapter_splash appList_Adapter_splash = new AppList_Adapter_splash(this, listUrl2, listIcon2, listName2);
                    runOnUiThread(new Runnable() {
                        public void run() {
                            MainActivity.this.app_list.setAdapter(appList_Adapter_splash);
                        }
                    });
                } else if (!this.isAlreadyCall) {
                    callApiForApplist();
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        } else {
            callApiForApplist();
        }
        this.app_list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                try {
                    MainActivity.this.startActivity(new Intent("android.intent.action.VIEW", Uri.parse(MainActivity.listUrl2.get(i))));
                } catch (ActivityNotFoundException unused) {
                    Toast.makeText(MainActivity.this, "You don't have Google Play installed", Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    /* access modifiers changed from: package-private */
    public void setTimeForApp() {
        this.pref.setPrefString(PreferencesUtils.TIME_OF_GET_APP_SPLASH, new SimpleDateFormat("dd-MM-yyyy HH:mm:ss").format(Calendar.getInstance().getTime()));
    }

    public void onClick(View view) {
        if (view.getId() == R.id.llstart) {
            startActivity(new Intent(this, StartActivity.class));
        }
    }

    private InterstitialAd showAdmobFullAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
            }

            public void onAdOpened() {
            }

            public void onAdClosed() {
                MainActivity.this.loadAdmobAd();
            }
        });
        return interstitialAd;
    }

    /* access modifiers changed from: private */
    public void loadAdmobAd() {
        this.mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
    }

    private void showAdmobInterstitial() {
        InterstitialAd interstitialAd = this.mInterstitialAdMob;
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            this.mInterstitialAdMob.show();
        }
    }

    public void onRequestPermissionsResult(int i2, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i2, strArr, iArr);
        if (i2 == 4) {
            if (iArr[0] == 0) {
                share();
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (checkSelfPermission("android.permission.READ_EXTERNAL_STORAGE") != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, 1);
                }
            }
        }
    }

    public void onBackPressed() {
        if (!isOnline()) {
            if (this.doubleBackToExitPressedOnce) {
                finish();
                super.onBackPressed();
            }
            this.doubleBackToExitPressedOnce = true;
            Snackbar make = Snackbar.make((View) this.banner_layout, (CharSequence) "click BACK again to exit", -1);
            ((TextView) make.getView().findViewById(R.id.snackbar_text)).setTextColor(-1);
            make.show();
            Toast.makeText(this, "click BACK again to exit", Toast.LENGTH_LONG);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    MainActivity.this.doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        } else if ((TextUtils.isEmpty(this.pref.getPrefString(PreferencesUtils.EXIT_JSON)) && !isOnline()) || !this.dataAvailable) {
            if (this.doubleBackToExitPressedOnce) {
                finish();
                super.onBackPressed();
            }
            this.doubleBackToExitPressedOnce = true;
            Snackbar make2 = Snackbar.make((View) this.banner_layout, (CharSequence) "click BACK again to exit", -1);
            ((TextView) make2.getView().findViewById(R.id.snackbar_text)).setTextColor(-1);
            make2.show();
            Toast.makeText(this, "click BACK again to exit", Toast.LENGTH_LONG);
            new Handler().postDelayed(new Runnable() {
                public void run() {
                    MainActivity.this.doubleBackToExitPressedOnce = false;
                }
            }, 2000);
        } else if (this.counter == 0) {
            startActivity(new Intent(this, BackActivity.class));
        }
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(this.mRegistrationBroadcastReceiver);
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}

package connectappzone.remotefortv.Activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.View.AVLoadingIndicatorView;
import java.util.Random;

public class ConnectingSycActivity extends Activity {
//    AVLoadingIndicatorView avi;
    CountDownTimer countDownTimer = null;
    ImageView imgback;
    LinearLayout lyok;
    int rndNumber;
    TextView txtDevice;
    TextView txtOk;
    int valNumber = 1;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_consyc);
        this.lyok = (LinearLayout) findViewById(R.id.lyok);
        this.txtOk = (TextView) findViewById(R.id.txtOk);
        this.txtDevice = (TextView) findViewById(R.id.txtDevice);
        TvConnection();
        this.rndNumber = new Random().nextInt(4) + 1;
        this.lyok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (ConnectingSycActivity.this.txtOk.getText().equals("Retry")) {
                    ConnectingSycActivity.this.TvConnection();
                } else if (ConnectingSycActivity.this.txtOk.getText().equals("Okay")) {
                    ConnectingSycActivity.this.startActivity(new Intent(ConnectingSycActivity.this, RemoteActivity.class));
                    ConnectingSycActivity.this.finish();
                }
            }
        });
    }

    public void TvConnection() {
        CountDownTimer r0 = new CountDownTimer(5000, 1000) {
            public void onTick(long j) {
                ConnectingSycActivity.this.txtDevice.setText("Device Need Some time to respond,wait a moment after the action");
            }

            public void onFinish() {
                ConnectingSycActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        if (ConnectingSycActivity.this.valNumber == ConnectingSycActivity.this.rndNumber) {
                            ConnectingSycActivity.this.txtOk.setText("Okay");
                            ConnectingSycActivity.this.txtDevice.setText("Your Connection is successfully done.");
                            ConnectingSycActivity.this.valNumber = 0;
                            return;
                        }
                        ConnectingSycActivity.this.txtOk.setText("Retry");
                        ConnectingSycActivity.this.txtDevice.setText("Your TV Connection is failed.Please Try again");
                        ConnectingSycActivity.this.valNumber++;
                    }
                });
            }
        };
        this.countDownTimer = r0;
        r0.start();
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}

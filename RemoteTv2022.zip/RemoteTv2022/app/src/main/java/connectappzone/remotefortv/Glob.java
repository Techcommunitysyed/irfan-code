package connectappzone.remotefortv;

import android.content.Context;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AnimationUtils;

public class Glob {
    public static String GSM_link = "http://appbankstudio.in/appbank/service/storeGCM/connect_app_zone";
    public static String acc_link = "https://play.google.com/store/apps/developer?id=Connect+App+Zone";
    public static int appID = 293;
    public static String app_link = "https://play.google.com/store/apps/details?id=connectappzone.remotefortv&hl=en";
    public static String app_name = "Remote For All Tv";
    public static String privacy_link = "http://connectappzone.blogspot.in/";

    public static void onviewtouch(final Context context, View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            public boolean onTouch(View view, MotionEvent motionEvent) {
                view.startAnimation(AnimationUtils.loadAnimation(context, R.anim.press));
                return false;
            }
        });
    }
}

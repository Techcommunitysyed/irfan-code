package connectappzone.remotefortv.Adapter;

import android.content.Context;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.helper.Constant;
import java.util.ArrayList;
import java.util.List;

public class MyAdapter extends BaseAdapter {
    Context context;
    List<String> data = new ArrayList();
    private LayoutInflater layoutInflater;
    SharedPreferences prefs;

    public String getItem(int i) {
        return null;
    }

    public long getItemId(int i) {
        return (long) i;
    }

    public class ViewHolder {
        ImageView imagetick;
        LinearLayout lyclick;
        TextView textView;

        public ViewHolder() {
        }
    }

    public MyAdapter(Context context2) {
        this.layoutInflater = (LayoutInflater) context2.getSystemService("layout_inflater");
        this.context = context2;
        this.prefs = context2.getSharedPreferences(Constant.preferences_name, 0);
    }

    public int getCount() {
        return this.data.size();
    }

    public void addall(List<String> list) {
        try {
            this.data.clear();
            this.data.addAll(list);
        } catch (Exception unused) {
        }
        notifyDataSetChanged();
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        View view2;
        ViewHolder viewHolder;
        if (view == null) {
            viewHolder = new ViewHolder();
            view2 = this.layoutInflater.inflate(R.layout.item, (ViewGroup) null);
            viewHolder.textView = (TextView) view2.findViewById(R.id.txtval);
            viewHolder.imagetick = (ImageView) view2.findViewById(R.id.imagetick);
            viewHolder.lyclick = (LinearLayout) view2.findViewById(R.id.lyclick);
            view2.setTag(viewHolder);
        } else {
            view2 = view;
            viewHolder = (ViewHolder) view.getTag();
        }
        try {
            viewHolder.textView.setText(this.data.get(i).toString());
            if (this.prefs.getString(Constant.tv_name, "Tv Name").equalsIgnoreCase(this.data.get(i).toString())) {
                viewHolder.imagetick.setVisibility(0);
            } else {
                viewHolder.imagetick.setVisibility(4);
            }
        } catch (Exception unused) {
        }
        return view2;
    }
}

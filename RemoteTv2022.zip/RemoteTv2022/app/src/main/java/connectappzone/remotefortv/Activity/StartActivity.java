package connectappzone.remotefortv.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import connectappzone.remotefortv.Adapter.MyAdapter;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.helper.Constant;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StartActivity extends AppCompatActivity {
    String[] arraylist = {"Toshiba", "Sharp", "Sony", "Scott", "Samsung", "Philips", "Pioneer", "Onida", "Asus", "Videocon", "Blue star", "BPL", "Hitachi", "LeEco", "Lloyd", "Oscar", "Weston", "Wybor", "TCL", "Hyundai", "Citizen", "VU", "Sansui", "Panasonic", "Micromax", "Mitsubishi", "LG", "Vizio", "RCA", "AOC", "Beltek", "Funai", "Haier", "InFocus", "Konca"};
    AdapterView.OnItemClickListener click_item = new AdapterView.OnItemClickListener() {
        public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
            StartActivity.this.editor.putString(Constant.tv_name, StartActivity.this.stringList.get(i));
            StartActivity.this.editor.commit();
            StartActivity.this.myAdapter.notifyDataSetChanged();
            Intent intent = new Intent(StartActivity.this, SecondActivity.class);
            if (StartActivity.this.prefs.getInt(Constant.flag_tv, 0) == 1) {
                StartActivity.this.setResult(-1, intent);
            } else {
                StartActivity.this.startActivity(intent);
                StartActivity.this.showAdmobInterstitial();
            }
            StartActivity.this.finish();
        }
    };
    SharedPreferences.Editor editor;
    private boolean flag = false;
    ImageView imgback;
    ListView listview;
    private InterstitialAd mInterstitialAdMob;
    MyAdapter myAdapter;
    SharedPreferences prefs;
    List<String> stringList;

    private InterstitialAd showAdmobFullAd() {
        InterstitialAd interstitialAd = new InterstitialAd(this);
        interstitialAd.setAdUnitId(getString(R.string.AdMob_InterstitialAd));
        interstitialAd.setAdListener(new AdListener() {
            public void onAdLoaded() {
            }

            public void onAdOpened() {
            }

            public void onAdClosed() {
                StartActivity.this.loadAdmobAd();
            }
        });
        return interstitialAd;
    }

    /* access modifiers changed from: private */
    public void loadAdmobAd() {
        this.mInterstitialAdMob.loadAd(new AdRequest.Builder().build());
    }

    /* access modifiers changed from: private */
    public void showAdmobInterstitial() {
        InterstitialAd interstitialAd = this.mInterstitialAdMob;
        if (interstitialAd != null && interstitialAd.isLoaded()) {
            this.mInterstitialAdMob.show();
        }
    }

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView((int) R.layout.activity_start);
        this.mInterstitialAdMob = showAdmobFullAd();
        loadAdmobAd();
        this.editor = getSharedPreferences(Constant.preferences_name, 0).edit();
        SharedPreferences sharedPreferences = getSharedPreferences(Constant.preferences_name, 0);
        this.prefs = sharedPreferences;
        if (sharedPreferences.getInt(Constant.flag_tv, 0) == 0) {
            if (this.prefs.getInt(Constant.first_lunch, 0) == 0) {
                this.editor.putInt(Constant.first_lunch, 1);
                this.editor.commit();
            } else if (this.prefs.getInt(Constant.second_lunch, 0) == 0) {
                this.editor.putInt(Constant.second_lunch, 1);
                this.editor.commit();
                startActivity(new Intent(this, SecondActivity.class));
            } else {
                startActivity(new Intent(this, ConnectingSycActivity.class));
            }
        }
        this.listview = (ListView) findViewById(R.id.listview);
        MyAdapter myAdapter2 = new MyAdapter(getApplicationContext());
        this.myAdapter = myAdapter2;
        this.listview.setAdapter(myAdapter2);
        ArrayList arrayList = new ArrayList(Arrays.asList(this.arraylist));
        this.stringList = arrayList;
        this.myAdapter.addall(arrayList);
        this.listview.setOnItemClickListener(this.click_item);
    }

    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}

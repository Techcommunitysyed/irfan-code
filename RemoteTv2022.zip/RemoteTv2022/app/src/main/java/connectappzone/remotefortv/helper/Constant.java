package connectappzone.remotefortv.helper;

public class Constant {
    public static String connection_mode = "Con_Mode";
    public static String first_lunch = "First_Lunch";
    public static String flag_con = "Flag_con";
    public static String flag_tv = "Flag_tv";
    public static String preferences_name = "My_Pref";
    public static String second_lunch = "Second_Lunch";
    public static String sound = "Sound";
    public static String tv_name = "Tv_Name";
    public static String vibration = "Vibration";
}

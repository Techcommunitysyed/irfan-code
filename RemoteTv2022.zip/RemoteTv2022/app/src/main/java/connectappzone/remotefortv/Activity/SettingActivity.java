package connectappzone.remotefortv.Activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.helper.Constant;

public class SettingActivity extends Activity {
    SharedPreferences.Editor editor;
    ImageView imgback;
    ImageView imgcon1;
    ImageView imgcon2;
    LinearLayout lyselectconnection;
    LinearLayout lyselecttv;
    LinearLayout lysound;
    LinearLayout lyvibration;
    SharedPreferences prefs;
    TextView txtconnectionname;
    TextView txtmodelname;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_setting);
        this.editor = getSharedPreferences(Constant.preferences_name, 0).edit();
        this.prefs = getSharedPreferences(Constant.preferences_name, 0);
        this.lyvibration = (LinearLayout) findViewById(R.id.lyvibration);
        this.lysound = (LinearLayout) findViewById(R.id.lysound);
        this.lyselecttv = (LinearLayout) findViewById(R.id.lyselecttv);
        this.lyselectconnection = (LinearLayout) findViewById(R.id.lyselectconnection);
        this.txtmodelname = (TextView) findViewById(R.id.txtmodelname);
        this.txtconnectionname = (TextView) findViewById(R.id.txtconnectionname);
        this.imgcon1 = (ImageView) findViewById(R.id.imgcon1);
        this.imgcon2 = (ImageView) findViewById(R.id.imgcon2);
        this.imgback = (ImageView) findViewById(R.id.imgback);
        if (this.prefs.getInt(Constant.vibration, 0) == 0) {
            this.imgcon1.setBackgroundResource(R.mipmap.radio_on);
        } else {
            this.imgcon1.setBackgroundResource(R.mipmap.radio_off);
        }
        if (this.prefs.getInt(Constant.sound, 0) == 0) {
            this.imgcon2.setBackgroundResource(R.mipmap.radio_on);
        } else {
            this.imgcon2.setBackgroundResource(R.mipmap.radio_off);
        }
        if (!this.prefs.getString(Constant.tv_name, "").equalsIgnoreCase("")) {
            this.txtmodelname.setText(this.prefs.getString(Constant.tv_name, ""));
        }
        if (!this.prefs.getString(Constant.connection_mode, "").equalsIgnoreCase("")) {
            this.txtconnectionname.setText(this.prefs.getString(Constant.connection_mode, ""));
        }
        this.lyvibration.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (SettingActivity.this.imgcon1.getBackground().getConstantState() == SettingActivity.this.getResources().getDrawable(R.mipmap.radio_on).getConstantState()) {
                    SettingActivity.this.imgcon1.setBackgroundResource(R.mipmap.radio_off);
                    SettingActivity.this.editor.putInt(Constant.vibration, 1);
                    SettingActivity.this.editor.commit();
                    return;
                }
                SettingActivity.this.imgcon1.setBackgroundResource(R.mipmap.radio_on);
                SettingActivity.this.editor.putInt(Constant.vibration, 0);
                SettingActivity.this.editor.commit();
            }
        });
        this.lysound.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                if (SettingActivity.this.imgcon2.getBackground().getConstantState() == SettingActivity.this.getResources().getDrawable(R.mipmap.radio_on).getConstantState()) {
                    SettingActivity.this.imgcon2.setBackgroundResource(R.mipmap.radio_off);
                    SettingActivity.this.editor.putInt(Constant.sound, 1);
                    SettingActivity.this.editor.commit();
                    return;
                }
                SettingActivity.this.imgcon2.setBackgroundResource(R.mipmap.radio_on);
                SettingActivity.this.editor.putInt(Constant.sound, 0);
                SettingActivity.this.editor.commit();
            }
        });
        this.lyselecttv.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SettingActivity.this.editor.putInt(Constant.flag_tv, 1);
                SettingActivity.this.editor.commit();
                SettingActivity.this.startActivityForResult(new Intent(SettingActivity.this, StartActivity.class), 1);
            }
        });
        this.lyselectconnection.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                SettingActivity.this.editor.putInt(Constant.flag_con, 1);
                SettingActivity.this.editor.commit();
                SettingActivity.this.startActivityForResult(new Intent(SettingActivity.this, SecondActivity.class), 2);
            }
        });
    }

    /* access modifiers changed from: protected */
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i == 1 && i2 == -1 && !this.prefs.getString(Constant.tv_name, "").equalsIgnoreCase("")) {
            this.txtmodelname.setText(this.prefs.getString(Constant.tv_name, ""));
            this.editor.putInt(Constant.flag_tv, 0);
            this.editor.commit();
        }
        if (i == 2 && i2 == -1 && !this.prefs.getString(Constant.connection_mode, "").equalsIgnoreCase("")) {
            this.txtconnectionname.setText(this.prefs.getString(Constant.connection_mode, ""));
            this.editor.putInt(Constant.flag_con, 0);
            this.editor.commit();
        }
    }
}

package connectappzone.remotefortv.Model;

public class SplashModel {
    private String AppLink;
    private String AppName;
    private String AppUrl;

    public SplashModel(String str, String str2, String str3) {
        this.AppName = str2;
        this.AppLink = str3;
        this.AppUrl = str;
    }

    public String getAppName() {
        return this.AppName;
    }

    public void setAppName(String str) {
        this.AppName = str;
    }

    public String getAppLink() {
        return this.AppLink;
    }

    public void setAppLink(String str) {
        this.AppLink = str;
    }

    public String getAppUrl() {
        return this.AppUrl;
    }

    public void setAppUrl(String str) {
        this.AppUrl = str;
    }
}

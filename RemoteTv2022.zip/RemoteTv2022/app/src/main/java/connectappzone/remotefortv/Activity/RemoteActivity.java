package connectappzone.remotefortv.Activity;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import connectappzone.remotefortv.R;
import connectappzone.remotefortv.helper.Constant;

public class RemoteActivity extends Activity {
    private ImageView enter;
    private boolean flag = false;
    Handler handler = new Handler();
    ImageView imginfo;
    ImageView imgmore;
    ImageView imgok;
    ImageView imgpower;
    ImageView imgsetting;
    ImageView imgtv;
    ImageView imgvlminus;
    ImageView imgvlplus;
    ImageView imgwire;
    private ImageView iv_back;
    private ImageView iv_eight;
    private ImageView iv_five;
    private ImageView iv_four;
    private ImageView iv_mute;
    private ImageView iv_nine;
    private ImageView iv_one;
    private ImageView iv_seven;
    private ImageView iv_six;
    private ImageView iv_three;
    private ImageView iv_two;
    private ImageView iv_zero;
    private ImageView plus_mise;
    SharedPreferences prefs;

    /* access modifiers changed from: protected */
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_remote2);
        this.prefs = getSharedPreferences(Constant.preferences_name, 0);
        this.imgpower = (ImageView) findViewById(R.id.imgpower);
        this.enter = (ImageView) findViewById(R.id.enter);
        this.plus_mise = (ImageView) findViewById(R.id.plus_mise);
        this.imgsetting = (ImageView) findViewById(R.id.imgsetting);
        this.imginfo = (ImageView) findViewById(R.id.imginfo);
        this.imgok = (ImageView) findViewById(R.id.imgok);
        this.iv_one = (ImageView) findViewById(R.id.iv_one);
        this.iv_two = (ImageView) findViewById(R.id.iv_two);
        this.iv_three = (ImageView) findViewById(R.id.iv_three);
        this.iv_four = (ImageView) findViewById(R.id.iv_four);
        this.iv_five = (ImageView) findViewById(R.id.iv_five);
        this.iv_seven = (ImageView) findViewById(R.id.iv_seven);
        this.iv_six = (ImageView) findViewById(R.id.iv_six);
        this.iv_eight = (ImageView) findViewById(R.id.iv_eight);
        this.iv_nine = (ImageView) findViewById(R.id.iv_nine);
        this.iv_zero = (ImageView) findViewById(R.id.iv_zero);
        this.iv_five.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_four.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_three.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_two.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_one.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_zero.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_nine.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_eight.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_six.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.iv_seven.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.plus_mise.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.imgpower.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteActivity.this.startActivity(new Intent(RemoteActivity.this, BackActivity.class));
                RemoteActivity.this.vibrate();
            }
        });
        this.imgsetting.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteActivity.this.vibrate();
                RemoteActivity.this.startActivity(new Intent(RemoteActivity.this, SettingActivity.class));
            }
        });
        this.imginfo.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteActivity.this.vibrate();
                final Dialog dialog = new Dialog(RemoteActivity.this);
                dialog.requestWindowFeature(1);
                dialog.setContentView(R.layout.cust_dialog);
                TextView textView = (TextView) dialog.findViewById(R.id.title);
                TextView textView2 = (TextView) dialog.findViewById(R.id.info);
                ((Button) dialog.findViewById(R.id.dialogButtonOK)).setOnClickListener(new View.OnClickListener() {
                    public void onClick(View view) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
        });
        this.enter.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Toast.makeText(RemoteActivity.this, "Your Device Is Not Support Infrared(IR)", 0).show();
                RemoteActivity.this.vibrate();
            }
        });
        this.imgok.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                RemoteActivity.this.vibrate();
            }
        });
    }

    public void vibrate() {
        if (this.prefs.getInt(Constant.vibration, 0) == 0) {
            try {
                ((Vibrator) getSystemService("vibrator")).vibrate(200);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /* access modifiers changed from: protected */
    public void onResume() {
        super.onResume();
    }

    /* access modifiers changed from: protected */
    public void onPause() {
        super.onPause();
    }

    /* access modifiers changed from: protected */
    public void onDestroy() {
        super.onDestroy();
    }
}

package connectappzone.remotefortv.Adapter;

import android.app.Activity;
import android.content.Context;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import connectappzone.remotefortv.R;
import java.util.ArrayList;

public class AppList_Adapter_splash extends BaseAdapter {
    private static LayoutInflater inflater;
    private Activity activity;
    ArrayList<String> dIcon = new ArrayList<>();
    ArrayList<String> dLink = new ArrayList<>();
    ArrayList<String> dName = new ArrayList<>();
    SparseBooleanArray mSparseBooleanArray;
    int width;

    public long getItemId(int i) {
        return (long) i;
    }

    public AppList_Adapter_splash(Activity activity2, ArrayList<String> arrayList, ArrayList<String> arrayList2, ArrayList<String> arrayList3) {
        this.activity = activity2;
        this.dLink = arrayList;
        this.dName = arrayList3;
        this.dIcon = arrayList2;
        inflater = (LayoutInflater) activity2.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mSparseBooleanArray = new SparseBooleanArray(this.dLink.size());
    }

    public int getCount() {
        return this.dLink.size();
    }

    public Object getItem(int i) {
        return Integer.valueOf(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        DisplayMetrics displayMetrics = this.activity.getResources().getDisplayMetrics();
        this.width = displayMetrics.widthPixels;
        int i2 = displayMetrics.heightPixels;
        if (view == null) {
            view = LayoutInflater.from(this.activity).inflate(R.layout.list_appstore_splace, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.imgIcon = (ImageView) view.findViewById(R.id.imglogo);
            viewHolder.txtname = (TextView) view.findViewById(R.id.txtname);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.txtname.setText(this.dName.get(i));
        ((RequestBuilder) ((RequestBuilder) Glide.with(this.activity).load(this.dIcon.get(i)).centerCrop()).placeholder((int) R.mipmap.ic_launcher)).into(viewHolder.imgIcon);
        System.gc();
        return view;
    }

    static class ViewHolder {
        ImageView imgIcon;
        TextView txtname;

        ViewHolder() {
        }
    }
}

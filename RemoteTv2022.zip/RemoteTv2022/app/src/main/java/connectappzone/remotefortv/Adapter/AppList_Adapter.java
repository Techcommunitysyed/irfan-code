package connectappzone.remotefortv.Adapter;

import android.app.Activity;
import android.content.Context;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import connectappzone.remotefortv.Model.SplashModel;
import connectappzone.remotefortv.R;
import java.util.ArrayList;

public class AppList_Adapter extends BaseAdapter {
    private static LayoutInflater inflater;
    private Activity activity;
    ArrayList<SplashModel> exitList = new ArrayList<>();
    SparseBooleanArray mSparseBooleanArray;

    public long getItemId(int i) {
        return (long) i;
    }

    public AppList_Adapter(Activity activity2, ArrayList<SplashModel> arrayList) {
        this.activity = activity2;
        this.exitList = arrayList;
        inflater = (LayoutInflater) activity2.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.mSparseBooleanArray = new SparseBooleanArray(arrayList.size());
    }

    public int getCount() {
        return this.exitList.size();
    }

    public Object getItem(int i) {
        return this.exitList.get(i);
    }

    public View getView(int i, View view, ViewGroup viewGroup) {
        ViewHolder viewHolder;
        if (view == null) {
            view = LayoutInflater.from(this.activity).inflate(R.layout.list_appstore, viewGroup, false);
            viewHolder = new ViewHolder();
            viewHolder.imgIcon = (ImageView) view.findViewById(R.id.imglogo);
            viewHolder.txtname = (TextView) view.findViewById(R.id.txtname);
            viewHolder.tv_install = (TextView) view.findViewById(R.id.tv_install);
            view.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.txtname.setText(this.exitList.get(i).getAppName());
        viewHolder.txtname.setSelected(true);
        ((RequestBuilder) Glide.with(this.activity).load(this.exitList.get(i).getAppUrl()).placeholder((int) R.mipmap.ic_launcher)).into(viewHolder.imgIcon);
        return view;
    }

    public class ViewHolder {
        ImageView imgIcon;
        TextView tv_install;
        TextView txtname;

        public ViewHolder() {
        }
    }
}
